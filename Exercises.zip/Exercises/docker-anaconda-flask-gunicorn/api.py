from flask import Flask, jsonify
app = Flask(__name__)
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn import decomposition, datasets
import csv
import numpy
from matplotlib import pyplot
import statsmodels.api as sm

@app.route('/')
def hello_world():

    df = pd.read_csv('/home/docker_conda_template/Data/ab_data_test.csv')
    
    df2 = df[['group', 'converted']]

    df2_control = df2.query('group == "control"')
    df2_treatment = df2.query('group == "treatment"')

    convert_old = len(df2_control[df2_control['converted'] == 1])
    convert_new = len(df2_treatment[df2_treatment['converted'] == 1])
    n_old = len(df2_control.index)
    n_new = len(df2_treatment.index)

    z_score, p_value = sm.stats.proportions_ztest([convert_old, convert_new], [n_old, n_new], alternative='smaller')
    
    results = formatedOutput(z_score, p_value)
    return results

@app.route('/ZTest')
def test():
    return jsonify({'message': 'This is Test'})

def formatedOutput(z_score, p_value):
    results = "<p>"+"z_score resault: " + z_score.astype('str') + "</p>"
    results = results + "<p>"+ "\n" + "\np_value resault: " + p_value.astype('str') + "</p>"
    

    if p_value >= 0.05:
        results = results + "<p>" +"\n" + "\nA is better than B" + "</p>"
    else:
        results = results + "<p>" +"\n" + "\nB is better than A" + "</p>"
    
    return results

if __name__ == "__main__":
    app.run(debuge=True)